const $=s=>document.querySelector(s);
const input=$("#input"), chat=$("#chat"), status=$("#status"), orb=$("#orb");
let history=JSON.parse(localStorage.getItem("tim_history")||"[]");
let settings=JSON.parse(localStorage.getItem("tim_settings")||'{"name":"Tim","voice":"on"}');

function save(){localStorage.setItem("tim_history",JSON.stringify(history))}
function bubble(role,text){const d=document.createElement("div");d.className="bubble "+role;d.textContent=text;chat.appendChild(d);chat.scrollTop=chat.scrollHeight}
function render(){chat.innerHTML="";history.forEach(m=>bubble(m.role,m.content))}
function speak(text){if(settings.voice==="off"||!("speechSynthesis"in window))return;speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.lang="es-MX";u.rate=.98;speechSynthesis.speak(u)}
async function send(){
 const text=input.value.trim(); if(!text)return;
 input.value=""; history.push({role:"user",content:text}); save(); bubble("user",text);
 status.textContent="Tim está pensando…"; orb.style.transform="scale(1.06)";
 try{
  const r=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({messages:history})});
  const data=await r.json();
  if(!r.ok) throw new Error(data.error||"Error");
  history.push({role:"assistant",content:data.reply});save();bubble("assistant",data.reply);status.textContent="Listo para conversar";speak(data.reply);
 }catch(e){bubble("assistant","No pude responder: "+e.message);status.textContent="Revisa la conexión o la configuración del servidor."}
 finally{orb.style.transform=""}
}
$("#send").onclick=send;input.addEventListener("keydown",e=>{if(e.key==="Enter")send()});
$("#settings").onclick=()=>$("#settingsDialog").showModal();
$("#closeSettings").onclick=()=>{$("#settingsDialog").close();settings.name=$("#name").value;settings.voice=$("#voiceMode").value;localStorage.setItem("tim_settings",JSON.stringify(settings))};
$("#clear").onclick=()=>{history=[];save();render()};
$("#name").value=settings.name;$("#voiceMode").value=settings.voice;render();

$("#mic").onclick=()=>{
 const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
 if(!SR){status.textContent="Tu navegador no permite dictado por voz.";return}
 const r=new SR();r.lang="es-MX";r.interimResults=false;r.onstart=()=>status.textContent="Escuchando…";
 r.onresult=e=>{input.value=e.results[0][0].transcript;send()};r.onerror=()=>status.textContent="No pude usar el micrófono.";r.onend=()=>status.textContent="Listo para conversar";r.start();
};