import express from "express";
import OpenAI from "openai";
import path from "path";
import { fileURLToPath } from "url";

const app = express();
const PORT = process.env.PORT || 3000;
const __dirname = path.dirname(fileURLToPath(import.meta.url));

app.use(express.json({ limit: "32kb" }));
app.use(express.static(path.join(__dirname, "public")));

function client() {
  const key = process.env.OPENAI_API_KEY;
  return key ? new OpenAI({ apiKey: key }) : null;
}

app.get("/api/health", (req, res) => {
  res.json({
    ok: true,
    aiConfigured: Boolean(process.env.OPENAI_API_KEY),
    model: process.env.OPENAI_MODEL || "gpt-5-mini"
  });
});

app.post("/api/chat", async (req, res) => {
  try {
    const messages = Array.isArray(req.body?.messages) ? req.body.messages : [];
    if (!messages.length) return res.status(400).json({ error: "No hay mensajes." });

    const safe = messages.slice(-20).filter(m =>
      m && ["user", "assistant"].includes(m.role) &&
      typeof m.content === "string" && m.content.length <= 4000
    );

    const ai = client();
    if (!ai) {
      return res.status(503).json({
        error: "TIM está listo, pero falta configurar OPENAI_API_KEY en los Secrets del servidor."
      });
    }

    const response = await ai.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5-mini",
      instructions:
        "Eres Tim, un asistente personal amable, claro y útil. " +
        "Responde en español latinoamericano. No afirmes que ejecutaste acciones del dispositivo si no tienes una herramienta que las haya ejecutado. " +
        "Mantén un tono tecnológico pero natural.",
      input: safe.map(m => ({ role: m.role, content: m.content }))
    });

    res.json({ reply: response.output_text || "No pude generar una respuesta." });
  } catch (err) {
    console.error(err);
    const status = Number(err?.status) || 500;
    res.status(status).json({
      error: status === 429
        ? "La API alcanzó un límite o no tiene cuota disponible."
        : "TIM no pudo comunicarse con el servicio de IA."
    });
  }
});

app.use((req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => console.log(`TIM AI escuchando en el puerto ${PORT}`));