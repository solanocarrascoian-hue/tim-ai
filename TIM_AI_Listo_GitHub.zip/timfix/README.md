# TIM AI

Asistente personal web con diseño negro/rojo.

## Ejecutar
1. Instala dependencias: `npm install`
2. Configura el secreto `OPENAI_API_KEY` en el entorno del servidor.
3. Opcionalmente configura `OPENAI_MODEL`.
4. Ejecuta: `npm start`
5. Abre la URL que muestre tu alojamiento.

## Incluye
- Chat con IA mediante servidor
- Historial local
- Dictado por voz cuando el navegador lo permite
- Respuestas habladas en español
- Configuración básica
- Diseño adaptable para iPad
- Endpoint `/api/health`

La clave de API nunca se coloca en el navegador.
